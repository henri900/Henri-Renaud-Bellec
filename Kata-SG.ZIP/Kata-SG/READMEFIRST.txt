Code r�alis� le 19 juin entre 12h30 et 14h30.

Il manque pas mal de choses, entre autres:

	* Un mod�le de donn�es
	* Des syst�mes d'authentification de base
	* Un minimum de mise en forme des r�sultats
	* Une javadoc digne de ce nom.
	
En plus des �l�ments propres au Kata en lui m�me, j'ai ajout�:

	* Une annotation "Function", servant en temps normal de point d'ancrage fonctionnel, pour synchronisation avec un mod�le fonctionnel.
	* Une annotation "command", qui permet en temps normal l'invocation des fonctions en ligne de commande (pour l'exploitation) avec un interpr�teur syntaxique minimaliste.
	
Ces deux �l�ments font syst�matiquement partie des structures que je met en place sur mes projets - je n'ai pas eu le temps de les g�n�raliser ou de coder l'interpr�teur syntaxique,
mais le but est surtout de montrer comment je travaille.

Renaud Bellec
