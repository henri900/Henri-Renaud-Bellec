package net.sg.kata;

import java.util.LinkedList;
import java.util.UUID;

public interface Account {

	/**
	 * Amount expected to be positive. Verification expected to be prior method call.
	 * @param amount
	 * @return
	 */
	Receipt withdraw(double amount);

	/**
	 * Amount expected to be positive. Verification expected to be prior method call.
	 * @param amount
	 * @return
	 */
	Receipt deposit(double amount);

	double getBalance();

	Bank getBank();

	Client getOwner();

	UUID getID();

	LinkedList<Operation> getOperations();

}