package net.sg.kata;

public interface Receipt {

}
