package net.sg.kata.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import net.sg.kata.Account;
import net.sg.kata.Bank;
import net.sg.kata.Client;
import net.sg.kata.annotations.Command;
import net.sg.kata.annotations.Function;
import net.sg.kata.annotations.Input;
import net.sg.kata.impl.AccountImpl;
import net.sg.kata.impl.BankImpl;
import net.sg.kata.impl.ClientImpl;

@Function(libelle="Account management service")
public class AccountService {

	private final Bank serviceOwner=new BankImpl();
	private final Hashtable<String, Client> allKnownClients=new Hashtable<String, Client>();
	private final Hashtable<Client, List<Account>> accounts=new Hashtable<Client, List<Account>>();
	
	/**
	 * TODO: Should be protected with adequate credentials
	 * @return
	 */
	public Hashtable<String, Client> getClients() {
		return allKnownClients;
	}


	public final static AccountService INSTANCE=new AccountService();
	
	public final Client authenticate(String login, String password){
		/*
		 *  Client expected to be dumb enough using login=firstname and password=name
		 *  (No time to code proper authentication function)
		 */
		return getClient(login, password);
	}
	
	private final Client getClient(String firstName, String name){
		String ID=new StringBuilder().append(firstName).append(name).toString();
		return this.allKnownClients.get(ID);
	}
	
	
	/**
	 * TODO: add client serialization
	 * @param name
	 * @param firstname
	 * @param birthDate
	 * @return
	 */
	public final Client registerClient(String name, String firstname, Date birthDate){
		Client toBeRegistered= new ClientImpl(name,firstname,birthDate);
		this.INSTANCE.allKnownClients.put(toBeRegistered.getID(), toBeRegistered);
		return toBeRegistered;
		
	}

	@Function(libelle="Account management service")
	@Command(statement="create account for client aClient with amount anAmount",
			inputs={@Input(name="aClient",type="net.sg.kata.Client")},
			outputs={}
			)
	public final Account makeAccount(Client owner, double initial){
		Account created=new AccountImpl(initial, serviceOwner, owner);
		List<Account> allExisting=this.getAccounts(owner);
		if(allExisting==null){
			allExisting=new ArrayList<Account>();
			accounts.put(owner, allExisting);
		}
		allExisting.add(created);
		return created;
	}
	
	
	
	public Bank getServiceOwner() {
		return serviceOwner;
	}
	
	public final List<Account> getAccounts(Client owner){
		return this.accounts.get(owner);
	}
	
}
