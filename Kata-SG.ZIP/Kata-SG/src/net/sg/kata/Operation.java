package net.sg.kata;

public interface Operation {

	/**
	 * Will be later extended to securities transactions
	 * @author rbellec
	 *
	 */
	public enum TYPE{
		DEPOSIT, WITHDRAWAL;
	}
	
	
	
}
