package net.sg.kata.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import net.sg.kata.Account;
import net.sg.kata.Bank;
import net.sg.kata.Client;
import net.sg.kata.Operation;
import net.sg.kata.Receipt;
import net.sg.kata.impl.BankImpl;
import net.sg.kata.service.AccountService;

public class TestIt {

	private final static SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-DD");

	public static void main(String[] args) {
		try {
			Bank testBank=AccountService.INSTANCE.getServiceOwner();
			Date myBirthDate=format.parse("1974-12-24");
			Client me=AccountService.INSTANCE.registerClient("Bellec", "Renaud", myBirthDate);
			Account createdAccount=AccountService.INSTANCE.makeAccount(me, 100d);
			
			System.out.println("Created account:"+createdAccount.getID());
			System.out.println();

			Receipt depositReceipt=createdAccount.deposit(100d);
			
			System.out.println("Deposit:"+depositReceipt);
			System.out.println();
			
			Receipt withdrawalReceipt=createdAccount.withdraw(50d);
			
			System.out.println("Withdrawal:"+withdrawalReceipt);
			
			List<Account> allAccounts=AccountService.INSTANCE.getAccounts(me);
			System.out.println();
			System.out.println("History");

			for (Account account : allAccounts) {
				List<Operation> operations=account.getOperations();
				System.out.println();
				System.out.println("Account:"+account.getID());
				System.out.println();
				for (Operation operation : operations) {
					System.out.println("\t"+operation.toString());
				}
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		

	}

}
