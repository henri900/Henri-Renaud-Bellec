package net.sg.kata;

public interface Bank {
	public String getName();
}