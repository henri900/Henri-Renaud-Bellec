package net.sg.kata;

import java.util.Date;

public interface Client {

	public String getName();

	public void setName(String name);

	public String getFirstname();

	public void setFirstname(String firstname);

	public Date getDateOfBirth();
	public String getID() ;

}