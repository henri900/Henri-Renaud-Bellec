package net.sg.kata.impl;

import java.util.Date;

import net.sg.kata.Client;

public class ClientImpl implements Client {
	private String name;
	private String firstname;
	private Date dateOfBirth;
	private String ID;
	

	public ClientImpl(String name, String firstname, Date dateOfBirth) {
		super();
		this.name = name;
		this.firstname = firstname;
		this.dateOfBirth = dateOfBirth;
		//TODO: add cryptographic unilateral function
		this.ID=new StringBuilder().append(this.firstname).append(this.name).toString();
	}

	/* (non-Javadoc)
	 * @see net.sg.kata.impl.Client#getName()
	 */
	@Override
	public String getName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see net.sg.kata.impl.Client#setName(java.lang.String)
	 */
	@Override
	public void setName(String name) {
		this.name = name;
	}

	/* (non-Javadoc)
	 * @see net.sg.kata.impl.Client#getFirstname()
	 */
	@Override
	public String getFirstname() {
		return firstname;
	}

	/* (non-Javadoc)
	 * @see net.sg.kata.impl.Client#setFirstname(java.lang.String)
	 */
	@Override
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	/* (non-Javadoc)
	 * @see net.sg.kata.impl.Client#getDateOfBirth()
	 */
	@Override
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	
	
	/* (non-Javadoc)
	 * @see net.sg.kata.impl.Client#getID()
	 */
	@Override
	public String getID() {
		return ID;
	}
	
	
	
	
}
