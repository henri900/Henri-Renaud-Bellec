package net.sg.kata.impl;

import java.util.Date;
import java.util.LinkedList;
import java.util.UUID;

import net.sg.kata.Account;
import net.sg.kata.Bank;
import net.sg.kata.Client;
import net.sg.kata.Operation;
import net.sg.kata.Receipt;

public class AccountImpl implements Account {
	private double balance;
	private Bank bank;
	private Client owner;
	private UUID ID;
	private LinkedList<Operation> operations=new LinkedList<Operation>();
	
	
	
	
	
	
	
	public AccountImpl(double balance, Bank bank, Client owner) {
		super();
		this.balance = balance;
		this.bank = bank;
		this.owner = owner;
		ID=UUID.randomUUID();
	}

	/* (non-Javadoc)
	 * @see net.sg.kata.impl.Account#withdraw(double)
	 */
	@Override
	public final Receipt withdraw(double amount){
		Date timestamp=new Date();
		// Just can't stand =+ and =-
		balance=balance-amount;
		Withdrawal operation=new Withdrawal(bank, owner, amount, timestamp);
		this.operations.add(operation);
		return makeReceipt(operation);
	}
	
	/* (non-Javadoc)
	 * @see net.sg.kata.impl.Account#deposit(double)
	 */
	@Override
	public final Receipt deposit(double amount){
		Date timestamp=new Date();
		balance=balance+amount;
		Deposit operation=new Deposit(bank, owner, amount, timestamp);
		this.operations.add(operation);
		return makeReceipt(operation);
		
	}
	
	
	private final static Receipt makeReceipt(Operation operation){
		
		return new ReceiptImpl(operation);
	}

	/* (non-Javadoc)
	 * @see net.sg.kata.impl.Account#getBalance()
	 */
	@Override
	public double getBalance() {
		return balance;
	}

	/* (non-Javadoc)
	 * @see net.sg.kata.impl.Account#getBank()
	 */
	@Override
	public Bank getBank() {
		return bank;
	}

	/* (non-Javadoc)
	 * @see net.sg.kata.impl.Account#getOwner()
	 */
	@Override
	public Client getOwner() {
		return owner;
	}

	/* (non-Javadoc)
	 * @see net.sg.kata.impl.Account#getID()
	 */
	@Override
	public UUID getID() {
		return ID;
	}

	/* (non-Javadoc)
	 * @see net.sg.kata.impl.Account#getOperations()
	 */
	@Override
	public LinkedList<Operation> getOperations() {
		return operations;
	}
	
	
	
	
	
}
