package net.sg.kata.impl;

import java.util.Hashtable;

import net.sg.kata.Bank;
import net.sg.kata.Client;
import net.sg.kata.service.AccountService;

public class BankImpl implements Bank {
	
	/**
	 * Sample identification data. Should be extended to adequate immatriculation.
	 */
	private final static String name="Whetever";
	
	public final AccountService getAccountService(){
		return AccountService.INSTANCE;
	}
	
	public final Hashtable<String,Client> getClients(){
		return AccountService.INSTANCE.getClients();
	}

	@Override
	public String getName() {
		return name;
	}
	
	
	
}
