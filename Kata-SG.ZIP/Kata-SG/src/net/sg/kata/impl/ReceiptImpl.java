package net.sg.kata.impl;

import net.sg.kata.Operation;
import net.sg.kata.Receipt;

public class ReceiptImpl implements Receipt{

	private String proof;

	public ReceiptImpl(Operation source) throws InstantiationError{
		//TODO: add proper security statement in order to avoid falsification
		this.proof = source.toString();
	}

	public String getProof() {
		return proof;
	}

	@Override
	public String toString() {
		return proof;
	}

	
}
