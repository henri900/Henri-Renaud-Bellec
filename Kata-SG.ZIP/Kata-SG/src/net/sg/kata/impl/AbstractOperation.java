package net.sg.kata.impl;

import java.util.Date;

import net.sg.kata.Bank;
import net.sg.kata.Client;
import net.sg.kata.Operation;

/**
 * 
 * @author rbellec
 *
 */
public class AbstractOperation implements Operation {

	private Operation.TYPE type;
	private double amount;
	private Date date;
	
	private Bank bank;
	private Client source;
	
	@Override
	public String toString() {
		return "[type=" + type + ", amount=" + amount + ", date=" + date + "]";
	}

	public AbstractOperation(Bank theBank, Client theClient,TYPE type, double amount, Date date) throws InstantiationError{
		super();
		// TODO: add proper
		this.type = type;
		this.amount = amount;
		this.date = date;
		this.bank=theBank;
		this.source=theClient;
	}
	
	
	
	
}
