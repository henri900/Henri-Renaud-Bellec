package net.sg.kata.impl;

import java.util.Date;

import net.sg.kata.Bank;
import net.sg.kata.Client;
import net.sg.kata.Operation;

public class Withdrawal extends AbstractOperation {

	public Withdrawal(Bank bank, Client client, double amount, Date date) throws InstantiationError {
		super(bank, client, Operation.TYPE.WITHDRAWAL, amount, date);
	}

}
