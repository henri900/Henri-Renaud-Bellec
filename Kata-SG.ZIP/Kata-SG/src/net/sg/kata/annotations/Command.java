package net.sg.kata.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Standard command line descriptor annotation.
 * @author rbellec
 *
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface Command {
	String statement();
	Input[] inputs();
	Output[] outputs();
}
