package net.sg.kata.annotations;

public @interface Input {
	String name();
	String type();
}
