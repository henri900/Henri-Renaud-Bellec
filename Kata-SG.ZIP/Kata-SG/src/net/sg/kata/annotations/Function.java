package net.sg.kata.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Standard function anchor annotation;
 * @author rbellec
 *
 */
@Retention(RetentionPolicy.SOURCE)
public @interface Function {
	String libelle();
}
