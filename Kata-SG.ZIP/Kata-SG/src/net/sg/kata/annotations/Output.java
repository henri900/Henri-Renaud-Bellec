package net.sg.kata.annotations;

public @interface Output {
	String name();
	String type();
}
